var brushThickness, red, green, blue;
var home;

function setup() {
  createCanvas(800, 570);
  background(255);
  brushThickness = 10;
  red = 0;
  green = 0;
  blue = 0;
  home = true;
}

function draw() {
  if (home)
    mainScreen();
  else
    drawOptions();
}

function mouseDragged() {
  if (mouseX > 150) {
    stroke(red, green, blue);
    strokeWeight(brushThickness);
    fill(red, green, blue);
    point(mouseX, mouseY);
  }
}

function keyPressed() {
  if (key == 'h' || key == 'H') {
    background(255);
    home = !home;
  }
}

function mouseClicked() {
  if (mouseX >= 75 && mouseX <= 105 &&
     	mouseY >= 60 && mouseY <= 90 &&
     	brushThickness < 100) {
  	brushThickness++;
  }
  if (mouseX >= 110 && mouseX <= 140 &&
     	mouseY >= 60 && mouseY <= 90 &&
     	brushThickness > 0) {
    brushThickness--;
  }
  
  // Red
  if (mouseX >= 7 && mouseX <= 67 &&
     	mouseY >= 240 && mouseY <= 270 &&
     	red < 255) {
    red++;
  }
  if (mouseX >= 75 && mouseX <= 135 &&
     	mouseY >= 240 && mouseY <= 270 &&
     	red > 0) {
    red--;
  }

  // Green
  if (mouseX >= 7 && mouseX <= 67 &&
     	mouseY >= 326 && mouseY <= 356 &&
     	green < 255) {
    green++;
  }
  if (mouseX >= 75 && mouseX <= 135 &&
     	mouseY >= 326 && mouseY <= 356 &&
     	green > 0) {
    green--;
  }
  
  // Blue
  if (mouseX >= 7 && mouseX <= 67 &&
     	mouseY >= 412 && mouseY <= 442 &&
     	blue < 255) {
    blue++;
  }
  if (mouseX >= 75 && mouseX <= 135 &&
     	mouseY >= 412 && mouseY <= 442 &&
     	blue > 0) {
    blue--;
  }
  if (mouseX >= 7 && mouseX <= 137 &&
     	mouseY >= 470 && mouseY <= 530) {
    fill(255);
    rect(150, 0, width - 150, height);
  }
  if (mouseX > 150) {
    stroke(red, green, blue);
    strokeWeight(brushThickness);
    fill(red, green, blue);
    point(mouseX, mouseY);
  }
}

function mouseWheel() {
  if (mouseX >= 75 && mouseX <= 105 &&
     	mouseY >= 60 && mouseY <= 90 &&
     	brushThickness < 100 &&
     	event.delta < 0) {
  	brushThickness++;
  }
  if (mouseX >= 110 && mouseX <= 140 &&
     	mouseY >= 60 && mouseY <= 90 &&
     	brushThickness > 0 &&
     	event.delta > 0) {
    brushThickness--;
  }
  // Red
  if (mouseX >= 7 && mouseX <= 67 &&
     	mouseY >= 240 && mouseY <= 270 &&
     	event.delta < 0 &&
     	red < 255) {
    red++;
  }
  if (mouseX >= 75 && mouseX <= 135 &&
     	mouseY >= 240 && mouseY <= 270 &&
     	event.delta > 0 &&
     	red > 0) {
    red--;
  }
  // Green
  if (mouseX >= 7 && mouseX <= 67 &&
     	mouseY >= 326 && mouseY <= 356 &&
     	event.delta < 0 &&
     	green < 255) {
    green++;
  }
  if (mouseX >= 75 && mouseX <= 135 &&
     	mouseY >= 326 && mouseY <= 356 &&
     	event.delta > 0 &&
     	green > 0) {
    green--;
  }
  
  // Blue
  if (mouseX >= 7 && mouseX <= 67 &&
     	mouseY >= 412 && mouseY <= 442 &&
     	event.delta < 0 &&
     	blue < 255) {
    blue++;
  }
  if (mouseX >= 75 && mouseX <= 135 &&
     	mouseY >= 412 && mouseY <= 442 &&
     	event.delta > 0 &&
     	blue > 0) {
    blue--;
  }
}

function drawOptions() {
  noStroke();
  fill(90);
  rect(0, 0, 150, height);
  
  // Brush thickness
  fill(255);
  textSize(20);
  text("Brush thickness", 5, 50);
  // Number
  rect(5, 60, 60, 30);
  // +
  rect(75, 60, 30, 30);
  // -
  rect(110, 60, 30, 30);
  
  fill(0);
  text(brushThickness, 10, 83);
  textSize(30);
  text("+", 82, 87);
  textSize(40);
  text("-", 119, 87);
  
  // Color
  fill(255);
  textSize(20);
  text("Color", 5, 150);

  strokeWeight(1);
  stroke(255);
  fill(red, green, blue);
  rect(75, 130, 60, 30);

  // Red
  noStroke();
  fill(255, 0, 0);
  text("Red", 7, 220);
  fill(255);
  // Number
  rect(75, 199, 60, 30);
  // +
  rect(7, 240, 60, 30);
  // -
  rect(75, 240, 60, 30);
  
  fill(0);
  textSize(30);
  text("+", 30, 266);
  textSize(40);
  text("-", 100, 266);
  textSize(20);
  text(red, 80, 222);

  // Green
  noStroke();
  fill(0, 255, 0);
  text("Green", 7, 310);
  fill(255);
  // Number
  rect(75, 285, 60, 30);
  // +
  rect(7, 326, 60, 30);
  // -
  rect(75, 326, 60, 30);

  fill(0);
  textSize(30);
  text("+", 30, 352);
  textSize(40);
  text("-", 100, 352);
  textSize(20);
  text(green, 80, 308);
  
	// Blue
  noStroke();
  fill(0, 0, 255);
  text("Blue", 7, 400);
  fill(255);
  // Number
  rect(75, 371, 60, 30);
  // +
  rect(7, 412, 60, 30);
  // -
  rect(75, 412, 60, 30);

  fill(0);
  textSize(30);
  text("+", 30, 438);
  textSize(40);
  text("-", 100, 438);
  textSize(20);
  text(blue, 80, 394);
  
  // clearScreen
  fill(255);
  rect(7, 470, 130, 60);
  fill(0);
	textSize(30);
	text("Clean", 30, 510);
}

function mainScreen() {
  background(0);
  fill(255);
  textSize(35);
  text("PAINT", width / 2 - 50, 75);
  textSize(20);
  text("Change brush thickness pressing '+' and '-' buttons with mouse.", width / 2 - 300, 150);
  text("You can also change the thickness of the brush by placing the cursor", width / 2 - 300, 200);
  text("over the buttons and moving the mouse wheel.", width / 2 - 300, 250);
  text("As with the brush, you can change the RGB colors with the buttons'", width / 2 - 300, 300);
  text("and the mouse wheel.", width / 2 - 300, 350);
  text("Press 'Clean' button to clean the screen", width / 2 - 300, 400);
  text("By clicking and dragging the mouse you can draw on the right side", width / 2 - 300, 450);
  text(" of the screen", width / 2 - 300, 500);
  textSize(15);
  text("Press H to continue and press again to return here", width / 2 - 135, height / 2 + 250);
}